
   <?php
    if(isset($_GET['edit_user'])){
        
        $the_user_id = $_GET['edit_user'];
        $query = "SELECT * FROM users WHERE user_id = $the_user_id";
            $select_users_query = mysqli_query($connection, $query);
            confirm($select_users_query);
            while($row = mysqli_fetch_assoc($select_users_query)){
                    $user_id = $row['user_id'];
                    $username = $row['username'];
                    $password = $row['user_password'];
                    $firstname = $row['user_firstname'];
                    $lastname = $row['user_lastname'];
                    $email = $row['user_email'];
                    $image = $row['user_image'];
                    $role = $row['user_role'];
            }

        
        if(isset($_POST['edit_user'])){
            $firstname = $_POST['user_firstname'];
            $lastname = $_POST['user_lastname'];
            $username = $_POST['username'];
            
            $email = $_POST['user_email'];
            $password = $_POST['user_password'];
            $role = $_POST['user_role'];
            $date = date('d-m-y');
            
            

            $query = "UPDATE users SET username = '{$username}', ";
            
            $query .= "user_firstname = '{$firstname}', ";
            $query .= "user_lastname = '{$lastname}', ";
            $query .= "user_role = '{$role}', ";
            $query .= "user_password = '{$password}', ";
            $query .= "user_email = '{$email}' ";
            $query .= "WHERE user_id = {$the_user_id}";
            
            
            $edit_query = mysqli_query($connection, $query);
            
            confirm($edit_query);
    
        }
?>

   
   
   <form action="" method ="post" enctype="multipart/form-data">
   
   <div class="form-group">
        
        <label for="firstname">First Name</label>
        <input value = "<?php echo $firstname?>" type="text" class="form-control" name = "user_firstname">
        
    </div>
    <div class="form-group">
        
        <label for="lastname">Last Name</label>
        <input value = "<?php echo $lastname?>"type="text" class="form-control" name = "user_lastname">
        
    </div>
    
    
    <div class="form-group">
        
        <label for="username">Username</label>
        <input value = "<?php echo $username?>"type="text" class="form-control" name = "username">
        
    </div>
    
    <div class="form-group">
        
        <label for="password">Password</label><br>
        <input value = "<?php echo $password?>"type="password" class="form-control" name = "user_password">
        
    </div>
    
    
    
    <div class="form-group">
        
        <label for="email">Email</label>
        <input value = "<?php echo $email?>"type="email" class="form-control" name = "user_email">
        
    </div>
    
    
    <div class="form-group">
       <label for="role">Role</label><br>
        <select name="user_role" id="">
            <option value = "<?php echo $role  ?>"><?php echo $role?></option>
            <option value="admin">admin</option>
            <option value="subscriber">aubscriber</option>
            
            
        </select>
    </div>

    

    
    <div class="form-group">
        <input class="btn btn-primary" type ="submit" name = "edit_user" value = "Edit User">
    </div>
    
    
</form>
<?php }?>