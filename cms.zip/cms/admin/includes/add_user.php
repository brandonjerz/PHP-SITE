
   <?php
        
        if(isset($_POST['create_user'])){
            $firstname = $_POST['user_firstname'];
            $lastname = $_POST['user_lastname'];
            $username = $_POST['username'];
            
            $email = $_POST['user_email'];
            $password = $_POST['user_password'];
            $role = $_POST['user_role'];
            $date = date('d-m-y');
            
            

$query = "INSERT INTO users(username, user_firstname, user_lastname, user_password, user_email, user_role) ";
$query .= "VALUES ('{$username}' , '{$firstname}',  '{$lastname}', '{$password}', '{$email}',  '{$role}')";
            
            
            $user_query = mysqli_query($connection, $query);
            
            confirm($user_query);
            echo "User Created: " . "<a href = 'users.php'> View Users</a>";
    
        }
?>

   
   
   <form action="" method ="post" enctype="multipart/form-data">
   
   <div class="form-group">
        
        <label for="firstname">First Name</label>
        <input type="text" class="form-control" name = "user_firstname">
        
    </div>
    <div class="form-group">
        
        <label for="lastname">Last Name</label>
        <input type="text" class="form-control" name = "user_lastname">
        
    </div>
    
    
    <div class="form-group">
        
        <label for="username">Username</label>
        <input type="text" class="form-control" name = "username">
        
    </div>
    
    <div class="form-group">
        
        <label for="password">Password</label><br>
        <input type="text" class="form-control" name = "user_password">
        
    </div>
    
    
    
    <div class="form-group">
        
        <label for="email">Email</label>
        <input type="email" class="form-control" name = "user_email">
        
    </div>
    
    
    <div class="form-group">
        <select name="user_role" id="">
            <option value="subscriber">Select Role</option>
            <option value="admin">Admin</option>
            <option value="subscriber">Subscriber</option>
            
            
        </select>
    </div>

    

    
    <div class="form-group">
        <input class="btn btn-primary" type ="submit" name = "create_user" value = "Create User">
    </div>
    
    
</form>