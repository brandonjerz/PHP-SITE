<form action="" method="post">
                                    <div class="form-group">
                                       <label for="cat-title">Edit Category</label>
                                       
                                       <?php
                                        global $connection;
                                        if(isset($_GET['cat_update'])){
                                            $cat_id = $_GET['cat_update'];
                                            
                                        
                                        $query = "SELECT * FROM categories WHERE cat_id = $cat_id";
                                        $select_categories_id = mysqli_query($connection, $query);
                                        while($row = mysqli_fetch_assoc($select_categories_id)){
                                                $cat_id = $row['cat_id'];
                                                $cat_title = $row['cat_title'];
                                        ?>
                                        <input value = "<?php if(isset($cat_title)){echo $cat_title;}?>" class = "form-control" type="text" name = "cat_update">
                                        <br>
                                        
                                        <?php } 
                                        
                                        if(isset($_POST['update_category'])){
                                                    echo "HERE";
                                                    $the_cat_title = $_POST['cat_update'];
                                                    
                                                    $query = "UPDATE categories SET cat_title = '{$the_cat_title}' WHERE cat_id = {$cat_id}";
                                                    $edit_query = mysqli_query($connection, $query);
                                                        if(!$edit_query){
                                                            die("QUERY FAILED" . mysqli_error($connection));
                                                        }
                                                    header("Location: categories.php"); 
                                                    
                                                }
                                        }
                                       ?>
                                        
                                    </div>
                                    <div class="form-group">
                                            <input class = "btn btn-primary" type="submit" name = "update_category" value = "Update Category">
                                        </div>
</form>