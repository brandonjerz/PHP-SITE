<?php include "includes/admin_header.php"?>


<?php 
    if(isset($_SESSION['username'])){
        
        $username = $_SESSION['username'];
        
        $query = "SELECT * FROM users WHERE username = '{$username}' ";
        $select_profile = mysqli_query($connection, $query);
        
        while($row = mysqli_fetch_array($select_profile)){
            $user_id = $row['user_id'];
            $username = $row['username'];
            $password = $row['user_password'];
            $firstname = $row['user_firstname'];
            $lastname = $row['user_lastname'];
            $email = $row['user_email'];
            $image = $row['user_image'];
            $role = $row['user_role'];
        }
    }

    if(isset($_POST['update_user'])){
            $firstname = $_POST['user_firstname'];
            $lastname = $_POST['user_lastname'];
            $username = $_POST['username'];
            
            $email = $_POST['user_email'];
            $password = $_POST['user_password'];
            $role = $_POST['user_role'];
            $date = date('d-m-y');
            
            

            $query = "UPDATE users SET username = '{$username}', ";
            
            $query .= "user_firstname = '{$firstname}', ";
            $query .= "user_lastname = '{$lastname}', ";
            $query .= "user_role = '{$role}', ";
            $query .= "user_password = '{$password}', ";
            $query .= "user_email = '{$email}' ";
            $query .= "WHERE user_id = {$user_id}";
            
            
            $edit_query = mysqli_query($connection, $query);
            
            confirm($edit_query);
    
        }
            
        
        
?>
<body>

   
   
   
   
    <div id="wrapper">

        <!-- Navigation -->
    <?php include "includes/admin_navigation.php"?>
        
        
        
        

        <div id="page-wrapper">

            <div class="container-fluid">

                <div class="row">
                   <div class="col-lg-12">
                       <h1 class = "page-header">Posts</h1>
                       
                       <?php 
                    

                        
                        
                        
                        ?>
                           <form action="" method ="post" enctype="multipart/form-data">
   
   <div class="form-group">
        
        <label for="firstname">First Name</label>
        <input value = "<?php echo $firstname?>" type="text" class="form-control" name = "user_firstname">
        
    </div>
    <div class="form-group">
        
        <label for="lastname">Last Name</label>
        <input value = "<?php echo $lastname?>"type="text" class="form-control" name = "user_lastname">
        
    </div>
    
    
    <div class="form-group">
        
        <label for="username">Username</label>
        <input value = "<?php echo $username?>"type="text" class="form-control" name = "username">
        
    </div>
    
    <div class="form-group">
        
        <label for="password">Password</label><br>
        <input value = "<?php echo $password?>"type="password" class="form-control" name = "user_password">
        
    </div>
    
    
    
    <div class="form-group">
        
        <label for="email">Email</label>
        <input value = "<?php echo $email?>"type="email" class="form-control" name = "user_email">
        
    </div>
    
    
    <div class="form-group">
       <label for="role">Role</label><br>
        <select name="user_role" id="">
            <option value = "<?php echo $role  ?>"><?php echo $role?></option>
            <option value="admin">admin</option>
            <option value="subscriber">aubscriber</option>
            
            
        </select>
    </div>

    

    
    <div class="form-group">
        <input class="btn btn-primary" type ="submit" name = "update_user" value = "Update User">
    </div>
    
    
</form>
                       
                   </div>
                    
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
    </div>
  
        
        
        
        
        <!-- /#page-wrapper -->
<?php include "includes/admin_footer.php"?>
