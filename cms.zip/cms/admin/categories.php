<?php include "includes/admin_header.php"?>

<body>
<br>
    <div id="wrapper">

        <!-- Navigation -->
    <?php include "includes/admin_navigation.php"?>
        
        
        
        

        <div id="page-wrapper">

            <div class="container-fluid">

                <div class="row">
                    <div class="col-lg-12">
                        <h1 class="page-header">
                            Welcome to Admin
                            <small>Author</small>
                        </h1>
                        
                       
                        <!-- LEFT SIDE FORM -->
                            <div class="col-xs-6">
                               
                               <?php 
                                /// User adds new category to database
                                insert_categories();
                                
                                ?>
                        
                                <form action="" method="post">
                                    <div class="form-group">
                                       <label for="cat-title">Add Category</label>
                                        <input class = "form-control" type="text" name = "cat_title">
                                        
                                    </div>
                            <div class="form-group">
                                <input class = "btn btn-primary" type="submit" name = "submit" value = "Add Category">
                                    </div>
                            
                                </form>
                                
                                <?php 
                                    if(isset($_GET['cat_update'])){
                                        include 'includes/edit_categories.php';
                                    }?>
                    </div>
                    <!-- RIGHT SIDE FORM -->

                            <div class="col-xs-6">
                                
                                <table class = "table table-bordered table-hover">
                                    <thead>
                                        <th>ID</th>
                                        <th>Category Title</th>
                                    </thead>
                                    <tbody>
                                        <tr>
                                          <?php 
                                            ///Inserts id and category name from categories table in DB
                                            build_table();
            
                                            
                                            ///Deletes an entry from the database, user selects which in table
                                            delete_row();
                                            
                                            ?>
                                        </tr>
                                    </tbody>
                                </table>
                                
                                
                            </div>
                </div>
                <!-- /.row -->

            </div>
            <!-- /.container-fluid -->

        </div>
    </div>
        
        
        
        
        
        
        <!-- /#page-wrapper -->
<?php include "includes/admin_footer.php"?>
